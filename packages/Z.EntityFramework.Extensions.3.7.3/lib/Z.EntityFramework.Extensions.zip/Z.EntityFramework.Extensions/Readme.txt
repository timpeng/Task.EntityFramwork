=== General Info ===
Library:	Z.EntityFramework.Extensions
Version: 	3.7.3
Date: 		2015/09/01

=== Description ===
Find out everything about the entity framework extensions and all of its innovative tools to ameliorate your performances and reduce your operations saving time drastically.

Here's a few available features:
- BulkSaveChanges
- Bulk operations: delete, insert, update and merge
- Caching
- Audit
- Runtime model
- Execute extensions : entities, dataset, datatable, etc.
And many more!

Learn more: http://www.zzzprojects.com/entity-framework-extensions/

=== Setup License Key ===
License Key setup is not required with the trial version.

For members, all information on how to setup your license key can be found here:
More informations: http://www.zzzprojects.com/setup-license/

=== Release History ===
http://www.zzzprojects.com/products/

=== Credit ===
ZZZ Projects
Email:	 			sales@zzzprojects.com
Website: 			http://www.zzzprojects.com/
Guides:				http://www.zzzprojects.com/guides/entity-framework-extensions/index.html
Demos:				http://www.zzzprojects.com/demos/entity-framework-extensions/bulksavechanges.aspx
UserVoice:			http://www.zzzprojects.uservoice.com/forums/283924
License agreement: 	http://www.zzzprojects.com/license-agreement/


Become a Member: 	http://www.zzzprojects.com/pricing/
Trial License Key: 	http://www.zzzprojects.com/products/

Copyright � 2015 ZZZ PROJECTS   All rights reserved.